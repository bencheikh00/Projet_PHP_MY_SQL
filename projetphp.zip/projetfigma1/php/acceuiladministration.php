<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./../css/figma.css" />
    <title>Iam administration</title>
</head>

<body id="one">
    <div class="header">
        <h1 id="tete"> <span class="a">IAM </span> <span class="b">ADMINIS</span><span class="c">TRATION<span> </h1>
        <img id="image" src="./../src/back.jpg">
    </div>
    <h1 id="connecter">
        <a href="connexion.php">Connecter</a>
    </h1>
</body>

</html>