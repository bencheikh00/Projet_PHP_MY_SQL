<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CATY PAVILLON</title>
    <link rel="stylesheet" href="./../css/style.css">
</head>

<body>
    <h2>IAM CAMPUS</h2>
    <br>
    <P>
        <HR NOSHADE>
    </P>
    <P>
        <HR NOSHADE>
    </P>
    <br><br>

    <ul>
        <div class="premier">
            <li><a href="inscrietudiant.php">INSCRIPTION</a> </li>
        </div>
    </ul>
    <ul>
        <div class="second">
            <li><a href="connexetudiant.php">CONNEXION</a> </li>
        </div>
    </ul>

</body>

</html>