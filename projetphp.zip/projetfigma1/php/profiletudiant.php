<!DOCTYPE html>
<html>

<head>
	<title>Profil étudiant</title>
	<link rel="stylesheet" type="text/css" href="./../css/profil.css">
</head>

<body>
	<h2>IAM CAMPUS</h2>

	<P>
		<HR NOSHADE>
	</P>
	<div class="container">
		<div class="profile-pic">
			<img src="./../src/profilstudent.jpg" alt="profil de l'étudiant">
		</div>
		<div class="info">
			<h1>joseph FAYE </h1>
			<h3>Etudiant Licence II en Informatique de GESTION</h3>
			<p>INFORMATIONS DE L'ETUDIANT:</p>
			<ul>
				<li><strong>Date de naissance:</strong> 05/09/2001</li>
				<li><strong>Adresse:</strong> Rue Davide Diop, Dakar, SENEGAL</li>
				<li><strong>Numéro de téléphone:</strong> +211 77 777 88 77</li>
				<li><strong>Email:</strong> josephfaye2001@gmail.com</li>
				<li><strong>Faculté:</strong> Informatique</li>
				<li><strong>Département:</strong> Département Science</li>
				<li><strong>Numéro étudiant:</strong> 2196339</li>
				<li><strong>Date d'inscription:</strong> 11/05/2022</li>
				<li><strong>Statut:</strong> Étudiant à temps plein</li>
				<li><strong>Clubs et organisations:</strong> AGE (Assemblée Générale des Etudiants)</li>
			</ul>
		</div>
	</div>
</body>

</html>