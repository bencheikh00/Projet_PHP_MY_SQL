<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caty Pavillon </title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="src/home.png">
</head>

<body>
    <h2> BIENVENUE AU GROUPE IAM</h2>
    <br>
    <P>
        <HR NOSHADE>
    </P>
    <P>
        <HR NOSHADE>
    </P>
    <br><br>
    <a href="php/cietudiant.php" class="btn">ETUDIANT</a>
    <a href="php/acceuiladministration.php" class="btn1">ADMINISTRATEUR</a>
</body>

</html>